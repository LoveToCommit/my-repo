package com.fasterxml.sort;

import junit.framework.TestCase;

public abstract class SortTestBase extends TestCase
{

}
