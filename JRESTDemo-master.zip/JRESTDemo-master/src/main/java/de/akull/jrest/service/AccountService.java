package de.akull.jrest.service;

import de.akull.jrest.entity.Account;
import java.net.URI;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;


@Path("/accounts")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Stateless
public class AccountService {
    @Context
    private UriInfo uriInfo;

    @PersistenceContext
    private EntityManager em;

    @POST
    public Response create(Account a) {
        if (a == null) {
            throw new BadRequestException();
        }
        if (a.getId() == 0) {
            em.persist(a);

            URI resourceUri = uriInfo.getAbsolutePathBuilder().path(String.valueOf(a.getId())).build();

            return Response.created(resourceUri).build();
        }
        else {
            throw new NotFoundException();
        }
    }

    @GET
    @Path("{id}")
    public Response read(@PathParam("id") Integer id) {
        Account a = em.find(Account.class, id);

        if (a == null) {
            throw new NotFoundException();
        }
        return Response.ok(a).build();
    }

    @GET
    public Response read() {
        List<Account> accounts = em.createNamedQuery(Account.ALL, Account.class).getResultList();

        return Response.ok(new GenericEntity<List<Account>>(accounts) {
        }).build();
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN})
    public Response update(@PathParam("id") Integer id, Account a) {
        if (a == null) {
            throw new BadRequestException();
        }
        if (em.find(Account.class, id) == null) {
            throw new NotFoundException();
        }
        a.setId(id);
        em.merge(a);

        return Response.ok(a).build();
    }

    @DELETE
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN})
    public Response delete(@PathParam("id") Integer id) {
        Account a = em.find(Account.class, id);

        if (a == null) {
            throw new NotFoundException();
        }
        em.remove(a);

        return Response.noContent().build();
    }
}
