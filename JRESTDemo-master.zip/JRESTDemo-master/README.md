JRESTDemo
=========

Short demo project for building a RESTful webservices with Java EE 7
