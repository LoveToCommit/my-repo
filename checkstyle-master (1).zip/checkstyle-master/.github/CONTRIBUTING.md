Please read http://checkstyle.sourceforge.net/report_issue.html

Please provide issue report in format that we request, EACH DETAIL MAKE A HUGE HELP.

Issues that are not following the guidelines, will be processed with last priority.