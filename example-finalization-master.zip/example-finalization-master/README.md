This is project contain example of implementing resource management
using Java finalizers and PhantomReferences.