package reftest;

public interface ResourceFacade {

    public void dispose();
}
