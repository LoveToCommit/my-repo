package com.stevesouza.jmx;

/**
 * Created by stevesouza on 11/19/14.
 */
public interface ExceptionInterface {
    public void throwException();
}
