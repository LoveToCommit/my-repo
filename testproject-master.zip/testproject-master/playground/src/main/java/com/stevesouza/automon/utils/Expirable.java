package com.stevesouza.automon.utils;

/**
 * Created by stevesouza on 3/3/15.
 */
public interface Expirable {
    public boolean isExpired();
}
