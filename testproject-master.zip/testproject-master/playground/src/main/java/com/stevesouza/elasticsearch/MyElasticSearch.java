package com.stevesouza.elasticsearch;

/**
 * Created by stevesouza on 4/23/14.
 */
public class MyElasticSearch {
}
