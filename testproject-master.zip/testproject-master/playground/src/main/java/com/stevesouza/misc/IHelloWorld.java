package com.stevesouza.misc;

/**
 * Created by stevesouza on 9/13/15.
 */
public interface IHelloWorld {

    String getResponse(String hello);

}
