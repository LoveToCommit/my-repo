import json

mylist = ["steven", "thomas", "souza"]
print mylist
print  json.dumps([1, 'simple', 'list'])
#write to file
# json.dump(x, file)

# from json file to json
# x = json.load(f)
