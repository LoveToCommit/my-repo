curl -s -XPOST 10.102.50.250:9200/_bulk --data-binary @bigbulkload.txt; echo
