# read the file into a string and print it

with open ("big.txt", "r") as myfile:
    data=myfile.read()
    
print data    
