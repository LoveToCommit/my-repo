 <?php
  $myvar = "HELLO";
 Echo "Hello, World!";
 echo get_include_path();
 echo toLower($myvar);

 function toLower($delme) {
     return strtolower($delme)."hi!!!";
 }

 ?> 
