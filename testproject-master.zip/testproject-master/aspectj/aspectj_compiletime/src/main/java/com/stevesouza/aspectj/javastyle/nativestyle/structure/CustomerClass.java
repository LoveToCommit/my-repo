package com.stevesouza.aspectj.javastyle.nativestyle.structure;

/**
 * Created by stevesouza on 6/23/15.
 */
public class CustomerClass  {

    public String getName() {
        return "Steve Souza";
    }
}
