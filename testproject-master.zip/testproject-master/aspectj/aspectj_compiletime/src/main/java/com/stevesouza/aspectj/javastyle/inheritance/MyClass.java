package com.stevesouza.aspectj.javastyle.inheritance;


/**
 * Created by stevesouza on 2/4/15.
 */
public class MyClass  {


    public void myMethod() {
    }

    public static void main(String[] args) {
        MyClass m = new MyClass();
        m.myMethod();
    }
}
