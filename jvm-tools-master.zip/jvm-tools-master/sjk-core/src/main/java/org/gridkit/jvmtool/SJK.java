package org.gridkit.jvmtool;

import org.gridkit.jvmtool.cli.CommandLauncher;

public class SJK extends CommandLauncher {

    public static void main(String[] args) {
        new SJK().start(args);
    }    
}
