package org.gridkit.jvmtool.stacktrace.analytics;

import org.gridkit.jvmtool.stacktrace.ThreadSnapshot;

public class WaitCallsAggregatorFactory implements ThreadDumpAggregator, ThreadDumpAggregatorFactory {

    @Override
    public ThreadDumpAggregator newInstance() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void aggregate(ThreadSnapshot threadInfo) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public Object info() {
        // TODO Auto-generated method stub
        return null;
    }

}
