Java 8: The Missing Tutorial Supporting Code
-----

This gradle Java 8 project houses example code that is used in the tutorial. Please refer to Table of Content to go to their respective packages inside the Java project.

## Table of Contents

* [Default and Static Methods for Interfaces](https://github.com/shekhargulati/java8-the-missing-tutorial/tree/master/code/src/main/java/com/shekhargulati/java8_tutorial/ch01)
