package com.shekhargulati.java8_tutorial.ch02;

/**
 *
 * Example of compiler unable to detect lambda expression types
 */
public class Example2_Lambda {

    public static void main(String[] args) {

//        Comparator comparator = (first, second) -> first.length() - second.length();


    }
}


