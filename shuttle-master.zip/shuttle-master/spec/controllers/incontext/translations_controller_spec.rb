require 'spec_helper'

describe Incontext::TranslationsController do
  # TODO:
  skip
end
