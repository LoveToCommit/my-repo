Paperclip::Attachment.default_options.merge! Shuttle::Configuration.paperclip.to_symbolized_hash
