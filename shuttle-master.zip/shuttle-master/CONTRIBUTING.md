Contributing
============

If you would like to contribute code to Shuttle, thank you! You can do so
through GitHub by forking one of the repositories and sending a pull request.
However, before your code can be accepted into the project we need you to sign
the (super simple) [Individual Contributor License Agreement (CLA)][1].

 [1]: https://spreadsheets.google.com/spreadsheet/viewform?formkey=dDViT2xzUHAwRkI3X3k5Z0lQM091OGc6MQ&ndplr=1
