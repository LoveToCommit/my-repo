# Copyright 2014 Square Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License");
#    you may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

class CreateArticles < ActiveRecord::Migration
  def up
    execute <<-SQL
      CREATE TABLE articles (
        id SERIAL PRIMARY KEY,
        project_id integer NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
        name text NOT NULL,
        name_sha_raw bytea NOT NULL,
        sections_hash text NOT NULL,
        base_rfc5646_locale character varying(255) NOT NULL,
        targeted_rfc5646_locales text NOT NULL,
        description text,
        email character varying(255),
        import_batch_id character varying(255),
        loading boolean DEFAULT false NOT NULL,
        ready boolean DEFAULT false NOT NULL,
        first_import_requested_at timestamp without time zone,
        last_import_requested_at timestamp without time zone,
        first_import_started_at timestamp without time zone,
        last_import_started_at timestamp without time zone,
        first_import_finished_at timestamp without time zone,
        last_import_finished_at timestamp without time zone,
        first_completed_at timestamp without time zone,
        last_completed_at timestamp without time zone,
        created_at timestamp without time zone NOT NULL,
        updated_at timestamp without time zone NOT NULL
      )
    SQL

    add_index(:articles, [:project_id])
    add_index(:articles, [:project_id, :name_sha_raw], unique: true)
  end

  def down
    drop_table :articles
  end
end
