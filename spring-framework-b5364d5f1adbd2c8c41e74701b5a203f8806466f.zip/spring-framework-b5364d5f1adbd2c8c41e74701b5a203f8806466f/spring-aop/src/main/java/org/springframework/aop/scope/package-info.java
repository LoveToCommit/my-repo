/**
 * Support for AOP-based scoping of target objects, with configurable backend.
 */
package org.springframework.aop.scope;
