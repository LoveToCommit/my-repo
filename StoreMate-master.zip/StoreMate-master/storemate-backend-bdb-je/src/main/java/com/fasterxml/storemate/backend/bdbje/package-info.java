/**
 * Package that contains main BDB-JE back-end implementation.
 */
package com.fasterxml.storemate.backend.bdbje;

