/**
 * Package that contains miscellaneous utility methods used
 * by BDB-JE backend implementation.
 */
package com.fasterxml.storemate.backend.bdbje.util;

