/**
 * Package that contains abstractions used by frontend to access
 * storage-system dependant backend implementations.
 */
package com.fasterxml.storemate.store.backend;

