package com.fasterxml.storemate.store.backend;

/**
 * Enum
 */
public enum IterationAction {
    PROCESS_ENTRY,
    SKIP_ENTRY,
    TERMINATE_ITERATION
    ;
}