package com.fasterxml.storemate.store.backend;

/**
 * Marker class used as the base for config objects used
 * by various {@link StoreBackend} implementations.
 */
public abstract class StoreBackendConfig
{

}
