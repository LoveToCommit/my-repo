/**
 * Package that contains core hashing interfaces and implementations
 * of StoreMate.
 */
package com.fasterxml.storemate.shared.hash;
