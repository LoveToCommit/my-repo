/**
 * Package that contains convenience access to standard compression
 * algorithsm (GZIP, LZF) that StoreMate supports.
 */
package com.fasterxml.storemate.shared.compress;
