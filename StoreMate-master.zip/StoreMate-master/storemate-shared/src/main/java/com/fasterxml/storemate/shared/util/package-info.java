/**
 * Package that contains miscellaneous utility methods used
 * by StoreMate classes.
 */
package com.fasterxml.storemate.shared.util;

