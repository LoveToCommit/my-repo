/**
 * Package that contains datatypes and utilities needed by storemate
 * store and core client functionality.
 */
package com.fasterxml.storemate.shared;

