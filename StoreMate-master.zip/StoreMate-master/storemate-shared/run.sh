#!/bin/sh

java -cp target/classes:target/test-classes $*
