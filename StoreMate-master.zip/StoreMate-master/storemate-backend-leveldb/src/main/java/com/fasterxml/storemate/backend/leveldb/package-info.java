/**
 * Package that contains main LevelDB (java) back-end implementation.
 */
package com.fasterxml.storemate.backend.leveldb;

