/**
Intermediate typed base classes that offer partial implementations
of API types and/or refinements, but do not fully implement them.
*/

package com.fasterxml.util.membuf.base;
