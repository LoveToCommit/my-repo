package com.github.lwhite1.tablesaw.filtering;

/**
 *
 */
public interface ShortPredicate {

  boolean test(short i);

}
