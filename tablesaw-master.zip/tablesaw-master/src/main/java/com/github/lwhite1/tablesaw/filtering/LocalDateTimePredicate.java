package com.github.lwhite1.tablesaw.filtering;

import java.time.LocalDateTime;

/**
 *
 */
public interface LocalDateTimePredicate {

  boolean test(LocalDateTime i);

}
