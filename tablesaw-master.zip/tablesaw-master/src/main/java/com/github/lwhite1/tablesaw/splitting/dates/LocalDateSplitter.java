package com.github.lwhite1.tablesaw.splitting.dates;

/**
 *
 */
public interface LocalDateSplitter {

  int split(int packedLocalDate);
}
