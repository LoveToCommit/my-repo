package com.github.lwhite1.tablesaw.filtering;

/**
 *
 */
public interface StringPredicate {

  boolean test(String i);

}
