package com.github.lwhite1.tablesaw.smile.classification;

/**
 *
 */
public class LogisticRegression {

}
